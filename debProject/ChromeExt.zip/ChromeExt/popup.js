function fetchNews(url, sourceName) {
    fetch(url, {
            method: 'GET',
            mode: "cors"
        })
        .then(response => response.text())
        .then(data => {
            const parser = new DOMParser();
            const xml = parser.parseFromString(data, 'application/xml');
            const items = xml.querySelectorAll('item');

            const newsList = document.getElementById('news-list');
            const sourceList = document.createElement('ul'); // create a new ul element for each source
            const sourceHeading = document.createElement('h2');
            sourceHeading.textContent = sourceName;
            sourceList.appendChild(sourceHeading);
            items.forEach(item => {
                const link = item.querySelector('link').textContent;
                const title = item.querySelector('title').textContent;
                const li = document.createElement('li');
                li.innerHTML = `<a href="${link}" target="_blank">${title}</a>`;
                sourceList.appendChild(li);
            });
            newsList.appendChild(sourceList); // append the new list to the main newsList
        })
        .catch(error => {
            console.error('Error fetching news:', error);
        });
}

document.addEventListener('DOMContentLoaded', function () {
    const urls = [{
            url: 'https://rss.nytimes.com/services/xml/rss/nyt/HomePage.xml',
            sourceName: 'New York Times'
        },
        // {
        //     url: 'https://rsshub.app/apnews/topics/top-news',
        //     sourceName: 'AP News'
        // },
        {
            url: 'https://www.startribune.com/local/index.rss2',
            sourceName: 'Star Tribune News'
        },
        // {
        //     url: 'https://feeds.foxnews.com/foxnews/latest',
        //     sourceName: 'Fox News'
        // },
        // {
        //     url: 'https://feeds.a.dj.com/rss/RSSWorldNews.xml',
        //     sourceName: 'Wall Street Journal'
        // }

    ];
    const button = document.getElementById('fetch-news-button');
    button.addEventListener('click', function () {
        urls.forEach(source => {
            fetchNews(source.url, source.sourceName);
        });
    });
});